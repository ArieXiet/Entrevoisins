# Entrevoisins

#### Pour exécuter et compiler l'application.

Tout d'abord récupérer le code. Pour cela sur la page principale du repository https://github.com/ArieXiet/Entrevoisins.git, cliquer sur "clone or download" puis, soit:
* copier l'URL, puis dans Android Studio cliquer sur '_File -> New -> Project from version control -> Git_' puis coller l'URL
* cliquer sur download zip, enregistrer le fichier sur votre ordinateur et le dézipper, 
puis dans Android Studio cliquer sur '_File -> Open_' et sélectionnez le dossier dézippé

En temps normal, la synchronisation du Gradle devrait se faire automatiquement, si ce n'est pas le cas ouvrir le fichier build.gradle(Module: app) et cliquer sur '_Sync now_' en haut à droite.

On peut enfin compiler l'application, soit en cliquant sur '_Build -> Make Project_', soit en utilisant le raccourci clavier ctrl+F9, soit en cliquant sur l'icône de marteau vert.

Et finalement pour exécuter l'application, choisir un appareil virtuel et cliquer sur '_Run -> Run app_' ou sur l'icône de flêche (triangle) verte, celà compilera puis exécutera l'application sur l'appareil sélectionné.
